1. instructions for running your scripts
	a. If you have make installed in your machine:
		type "make load" to execute the load_tp2.py
		type "make train" to execute the train_tp2.py
	b. If you don't have make:
		type "python3 load_tp2.py" to execute the load_tp2.py
		type "python3 train_tp2.py" to execute the load_tp2.py

2. running time for both scripts 
Not done yet

3. all non-default gensim parameter settings for both scripts

all are default for both (still prototyping)

4. a brief description of the method used for obtaining sentence embeddings

I am still in the step of understanding how I can perform a transition from word embedding to sentence embedding.

5. a brief description of the choice of the training corpus

- 
