# TP1: Fabrice Hategekimana 
 
## Result
I was able to produce the expected results. But there are still things to improve.

# Future work

- Finalise the implementation of the PMI (actually it just use the count of words).
- Find a way to exploit the cosine similarity matrix for the project
- Implement the remaining TODOs
- Add more tests to make the program more robust


